class Snake {
	constructor() {
		this.body = [{x: 10, y: 10}, {x: 9, y: 10}, {x: 8, y: 10}];
		this.direction = "right";
	}

	move() {
		let head = {x: this.body[0].x, y: this.body[0].y};

		switch(this.direction) {
			case "right":
				head.x++;
				break;
			case "left":
				head.x--;
				break;
			case "up":
				head.y--;
				break;
			case "down":
				head.y++;
				break;
		}

		this.body.unshift(head);
		this.body.pop();
	}

	changeDirection(direction) {
		switch(direction) {
			case "right":
				if (this.direction !== "left") {
					this.direction = "right";
				}
				break;
			case "left":
				if (this.direction !== "right") {
					this.direction = "left";
				}
				break;
			case "up":
				if (this.direction !== "down") {
					this.direction = "up";
				}
				break;
			case "down":
				if (this.direction !== "up") {
					this.direction = "down";
				}
				break;
		}
	}

	draw() {
		for (let i = 0; i < this.body.length; i++) {
			ctx.fillStyle = "#000";
			ctx.fillRect(this.body[i].x * grid, this.body[i].y * grid, grid, grid);
			ctx.strokeStyle = "#fff";
			ctx.strokeRect(this.body[i].x * grid, this.body[i].y * grid, grid, grid);
		}
	}

	collidesWith(food) {
		return this.body[0].x === food.x && this.body[0].y === food.y;
	}
}

class Food {
	constructor() {
		this.x = Math.floor(Math.random() * (canvas.width / grid));
		this.y = Math.floor(Math.random() * (canvas.height / grid));
	}

	draw() {
		ctx.fillStyle = "#f00";
		ctx.fillRect(this.x * grid, this.y * grid, grid, grid);
		ctx.strokeStyle = "#fff";
		ctx.strokeRect(this.x * grid, this.y * grid, grid, grid);
	}
}

const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
const grid = 20;

let snake = new Snake();
let food = new Food();
let score = 0;

function draw() {
	ctx.clearRect(0, 0, canvas.width, canvas.height);

	snake.draw();
	food.draw();

	ctx.fillStyle = "#fff";
	ctx.font = "20px Arial";
	ctx.fillText(`Score: ${score}`, 10, 30);
}

function update() {
	snake.move();

	if (snake.collidesWith(food)) {
		score++;
		food = new Food();
	}

	if (snake.body[0].x < 0 || snake.body[0].x >= canvas.width / grid || snake.body[0].y < 0 || snake.body[

        document.addEventListener("keydown", function(event) {
            switch(event.code) {
                case "ArrowRight":
                    snake.changeDirection("right");
                    break;
                case "ArrowLeft":
                    snake.changeDirection("left");
                    break;
                case "ArrowUp":
                    snake.changeDirection("up");
                    break;
                case "ArrowDown":
                    snake.changeDirection("down");
                    break;
            }
        });
        
        setInterval(function() {
            update();
            draw();
        }, 100);
        